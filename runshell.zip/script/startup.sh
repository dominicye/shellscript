chmod 777 /home/app/*.jar
echo "执行....."
cd /home/app/
java -jar live.jar
echo "**********************cmp on  jenkins started*************************"

